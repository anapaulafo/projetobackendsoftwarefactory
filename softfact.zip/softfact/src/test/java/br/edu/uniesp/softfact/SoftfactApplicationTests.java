package br.edu.uniesp.softfact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftfactApplicationTests {

	@Test
	void contextLoads() {
	}

}
