package br.edu.uniesp.softfact.boundaries.rest.stack;

public class StackQueryController {
}
