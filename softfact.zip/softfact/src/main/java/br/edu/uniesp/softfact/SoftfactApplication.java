package br.edu.uniesp.softfact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftfactApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoftfactApplication.class, args);
	}

}
