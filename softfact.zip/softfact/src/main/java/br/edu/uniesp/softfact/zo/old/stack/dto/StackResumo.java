package br.edu.uniesp.softfact.zo.old.stack.dto;

public record StackResumo(Long id, String nome, String categoria) {}

